using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanReceiver : MonoBehaviour
{
    [SerializeField] private float _speed = 50.0f;

    private void Start() {
        GestureManager.Instance.OnPan += this.OnPan;
    }

    private void OnDisable() {
        GestureManager.Instance.OnPan -= this.OnPan;
    }

    public void OnPan(object sender, PanEventArgs args) {
        Vector2 touchDeltaPos = args.TrackedFingers[0].deltaPosition;
        transform.Translate(-touchDeltaPos.x * _speed, -touchDeltaPos.y * _speed, 0);
    }
}
